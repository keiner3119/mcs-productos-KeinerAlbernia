package com.main.infrastructure.utilities;

public class Constants {

    private Constants() {
    }

    public static final String QUERY_CATEGORIES_WHITOUT_PRODUCTS
        = "${query.findCategoriesWithoutProducts}";
}