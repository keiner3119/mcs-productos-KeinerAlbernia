package com.main.application.category.dtos;

public class CreateCategoryRequestDto {
    public String nombre;
    public String descripcion;
}