package com.main.application.category.dtos;

import com.main.application.utilities.ResponseGenericDto;

public class ReadCategoryResponseDto extends ResponseGenericDto {
    public CategoryDto category = new CategoryDto();
}