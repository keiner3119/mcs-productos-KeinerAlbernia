package com.main.application.category.dtos;

import com.main.application.utilities.ResponseGenericDto;

public class CreateCategoryResponseDto extends ResponseGenericDto {
    public CategoryDto category = new CategoryDto();
}