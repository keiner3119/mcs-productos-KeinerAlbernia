package com.main.application.category.dtos;

import java.util.UUID;

public class UpdateCategoryRequestDto {
    public UUID id;
    public String nombre;
    public String descripcion;
}