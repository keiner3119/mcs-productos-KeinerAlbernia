package com.main.application.product.dtos;

import com.main.application.utilities.ResponseGenericDto;

public class CreateProductResponseDto extends ResponseGenericDto {
    public ProductDto product = new ProductDto();
}