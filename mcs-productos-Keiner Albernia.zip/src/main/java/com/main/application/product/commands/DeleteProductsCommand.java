package com.main.application.product.commands;

public class DeleteProductsCommand {
}
