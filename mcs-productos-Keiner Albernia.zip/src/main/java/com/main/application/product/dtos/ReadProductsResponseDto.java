package com.main.application.product.dtos;

public class ReadProductsResponseDto {
}
