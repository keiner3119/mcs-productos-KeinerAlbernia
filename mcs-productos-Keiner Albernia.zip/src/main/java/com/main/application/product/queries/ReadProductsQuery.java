package com.main.application.product.queries;

public class ReadProductsQuery {
}
