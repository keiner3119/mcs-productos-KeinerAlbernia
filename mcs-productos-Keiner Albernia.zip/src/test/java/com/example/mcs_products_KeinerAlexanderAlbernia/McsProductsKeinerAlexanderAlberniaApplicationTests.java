package com.example.mcs_products_KeinerAlexanderAlbernia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class McsProductsKeinerAlexanderAlberniaApplicationTests {

	@Test
	void contextLoads() {
	}

}
